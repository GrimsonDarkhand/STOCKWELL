
from PyQt5.QtWidgets import QDialog, QVBoxLayout, QHBoxLayout, QLineEdit, QPushButton, QMessageBox, QComboBox, QLabel, QFrame
from PyQt5.QtCore import Qt

class ContributeDialog(QDialog):
    def __init__(self, controller, parent=None):
        super().__init__(parent)
        self.controller = controller
        self.init_ui()
        self.load_stokvels()

    def init_ui(self):
        self.setWindowTitle("Contribute to Stokvel")
        self.setFixedSize(400, 250)
        self.setStyleSheet("""
            QDialog {
                background-color: #f5f5f5;
                font-family: Arial, sans-serif;
            }
            QLabel {
                color: #333;
                font-size: 14px;
            }
            QLineEdit, QComboBox {
                padding: 10px;
                border: 2px solid #ddd;
                border-radius: 5px;
                font-size: 14px;
                margin: 5px 0;
            }
            QLineEdit:focus, QComboBox:focus {
                border-color: #4CAF50;
            }
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                padding: 12px 20px;
                border-radius: 5px;
                font-size: 14px;
                font-weight: bold;
                margin: 5px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
            QFrame {
                background-color: white;
                border-radius: 8px;
                padding: 20px;
            }
        """)

        main_layout = QVBoxLayout()
        
        # Content frame
        content_frame = QFrame()
        content_layout = QVBoxLayout(content_frame)

        title_label = QLabel("Make a Contribution")
        title_label.setStyleSheet("font-size: 18px; font-weight: bold; color: #4CAF50; margin-bottom: 15px;")
        title_label.setAlignment(Qt.AlignCenter)
        content_layout.addWidget(title_label)

        # Stokvel selection
        stokvel_label = QLabel("Select Stokvel:")
        content_layout.addWidget(stokvel_label)
        
        self.stokvel_combo = QComboBox()
        content_layout.addWidget(self.stokvel_combo)

        # Amount input
        amount_label = QLabel("Contribution Amount:")
        content_layout.addWidget(amount_label)
        
        self.amount_input = QLineEdit()
        self.amount_input.setPlaceholderText("Enter amount (R)")
        content_layout.addWidget(self.amount_input)

        # Button layout
        button_layout = QHBoxLayout()
        
        self.cancel_button = QPushButton("Cancel")
        self.cancel_button.setStyleSheet("""
            QPushButton {
                background-color: #757575;
            }
            QPushButton:hover {
                background-color: #616161;
            }
        """)
        self.cancel_button.clicked.connect(self.reject)
        button_layout.addWidget(self.cancel_button)

        self.contribute_button = QPushButton("Contribute")
        self.contribute_button.clicked.connect(self.contribute)
        button_layout.addWidget(self.contribute_button)

        content_layout.addLayout(button_layout)
        main_layout.addWidget(content_frame)
        self.setLayout(main_layout)

    def load_stokvels(self):
        data = self.controller.get_data()
        current_user = self.controller.current_user
        if current_user:
            user_stokvels = data["users"][current_user]["stokvels"]
            self.stokvel_combo.addItems(user_stokvels)

    def contribute(self):
        stokvel_name = self.stokvel_combo.currentText()
        amount_str = self.amount_input.text()

        if not stokvel_name:
            QMessageBox.warning(self, "Input Error", "Please select a stokvel.")
            return
        if not amount_str:
            QMessageBox.warning(self, "Input Error", "Amount cannot be empty.")
            return

        try:
            amount = float(amount_str)
            if amount <= 0:
                raise ValueError
        except ValueError:
            QMessageBox.warning(self, "Input Error", "Please enter a valid positive number for amount.")
            return

        success, message = self.controller.contribute(stokvel_name, amount)
        if success:
            QMessageBox.information(self, "Success", message)
            self.accept() # Close dialog
        else:
            QMessageBox.warning(self, "Error", message)


